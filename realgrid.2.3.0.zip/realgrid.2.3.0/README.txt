## READ ME

예제: https://github.com/realgrid/realgrid2-examples
문의: support@realgrid.com
개발용 라이선스 발급: http://service.realgrid.com/start 

## 제품 버전

파일 명에 명시되어 있으며, html 파일에 include 후 RealGrid.getVersion() 으로는 빌드번호를 포함하여 버전을 알 수 있다.

## Assets

styles(리얼그리드 테마)와 realgrid2-utils(유틸 함수 모음)는 realgrid.2.x.x.min.js 가 위치한 폴더에 존재한다.

libs - 사용하는 외부 라이브러리 (jszip)